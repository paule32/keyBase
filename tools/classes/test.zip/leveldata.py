import numpy as np
import isohelper
import cv2

levelData = np.matrix([
  [1,1,1,1,1,1],
  [1,0,0,2,0,1],
  [1,0,0,0,0,1],
  [1,0,0,0,0,1],
  [1,1,1,1,1,1]
])

tileWidth = 50
borderOffsetX = 70
borderOffsetY = 275

id = 0
tileType = 0

def do_tileStuff():
	id = 0
	pos.x = j * tileWidth
	pos.y = i * tileWidth
	pos = IsoHelper.twoDTwoIso(pos)

def placeTile(id,i,j):
	if (id == 1):
		do_tileStuff()

def createLevel():
	pos = cv2.Point()
	i = 0
	while (i < 5):
		i += 1
		j = 0
		while (j < 6):
			j += 1
			tileType = levelData[i][j]
			placeTile(tileType,i,j)
