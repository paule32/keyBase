import numpy as Math
import cv2

class IsoHelper:
	def __init__(self):
		__pass

	def isoTo2D(self, pt):
		tempPt = cv2.Point(0,0)
		tempPt.x = (2*pt.y+pt.x)/2
		tempPt.y = (2*pt.y-pt.x)/2
		return tempPt

	def twoDToIso(self, pt):
		tempPt = cv2.Point(0,0)
		tempPt.x = (pt.x-pt.y)
		tempPt.y = (pt.x+pt.y)/2
		return tempPt

	def getTileCoordinates(self, pt, tileHeight):
		tempPt = cv2.Point(0,0)
		tempPt.x = Math.floor(pt.x/tileHeight)
		tempPt.y = Math.floor(pt.y/tileHeight)
		return tempPt

	def get2dFromTileCoordinates(self, pt, tileHeight):
		tempPt = Point(0,0);
		tempPt.x =pt.x*tileHeight;
		tempPt.y =pt.y*tileHeight;
 		return tempPt;

